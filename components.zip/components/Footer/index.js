import React, {Component} from "react";

import "./styles.css"

import { AiOutlineBars } from "react-icons/ai";




class Footer extends Component {
    render() {
        return (

                <footer>
                    <Footer id="main-footer">
                  apdipansipdni
                    </Footer>
                </footer>

        );
    }
};




export default Footer;