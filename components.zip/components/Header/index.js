import React from "react";

import "./styles.css"

import { AiOutlineBars } from "react-icons/ai";



const Header = () => [
    <div id="main-div" ><header id="main-header">SpirandeliDev</header>
    <AiOutlineBars/></div>


];




export default Header;
